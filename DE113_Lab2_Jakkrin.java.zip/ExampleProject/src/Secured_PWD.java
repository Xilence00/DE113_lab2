import java.util.Scanner;
public class Secured_PWD {
    public static void main(String[] args) {
        String first,sbuff,second,tbuff,third,fourth,comb;
        Scanner myObj = new Scanner(System.in);  // Create a Scanner object
        System.out.println("Enter username :");
        String userName = myObj.nextLine();
        first = userName.substring(0,userName.indexOf(" "));
        sbuff = userName.substring(userName.indexOf(" ")+1,userName.length());
        second = sbuff.substring(0,sbuff.indexOf(" "));
        tbuff = sbuff.substring(sbuff.indexOf(" ")+1,sbuff.length());
        third = tbuff.substring(0,tbuff.indexOf(" "));
        fourth = tbuff.substring(tbuff.indexOf(" ")+1,tbuff.length());
        comb = first.substring(0,1)+first.substring(first.length()-1,first.length())+second.substring(0,1)+second.substring(second.length()-1,second.length())+third.substring(0,1)+third.substring(third.length()-1,third.length())+fourth.substring(0,1)+fourth.substring(fourth.length()-1,fourth.length());
        System.out.println(comb.toUpperCase());

    }

}
