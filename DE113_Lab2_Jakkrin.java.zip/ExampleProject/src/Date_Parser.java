import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
public class Date_Parser {
    public static void main(String[] args) {
        Date today = new Date();
        SimpleDateFormat sdf;
        sdf = new SimpleDateFormat("MM-dd-yyyy  (EEEE)");
        String data = sdf.format(today);
        String month = data.substring(0,2);
        String day = data.substring(3,5);
        String year = data.substring(6,11);
        System.out.println(data);
        System.out.println("Month : "+ month);
        System.out.println("Day : "+ day);
        System.out.println("Year : "+ year);
    }
}

