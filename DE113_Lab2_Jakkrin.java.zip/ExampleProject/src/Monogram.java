import java.util.Scanner;
public class Monogram {
    public static void main(String[] args) {
        String str1,fname,mnamebuff,mname,lname,monogram;
        str1 = new String("Andrew Lloyd Weber");
        fname = str1.substring(0,str1.indexOf(" "));
        mnamebuff = str1.substring(str1.indexOf(" ")+1,str1.length());
        mname = mnamebuff.substring(0,mnamebuff.indexOf(" "));
        lname = mnamebuff.substring(mnamebuff.indexOf(" ")+1,mnamebuff.length());
        monogram = fname.substring(0,1)+mname.substring(0,1)+lname.substring(0,1);
        System.out.println(monogram);
    }
}